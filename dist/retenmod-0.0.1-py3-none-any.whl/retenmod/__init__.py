from .model_funcs import bdw, bg, lcw
